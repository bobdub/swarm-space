package main

import (
 "crypto/rand"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "io"
 "log"
 "net/http"
 "os"
 "strings"
 "sync"
 "time"
)
const protocol = "swarm-local-companion-v1"
const host = "127.0.0.1:8545"
type RPC struct { JSONRPC string `json:"jsonrpc"`; ID json.RawMessage `json:"id"`; Method string `json:"method"`; Params []json.RawMessage `json:"params"` }
type Job struct { ID string `json:"id"`; Method string `json:"method"`; Params []json.RawMessage `json:"params"` }
type Reply struct { ID string `json:"id"`; Result json.RawMessage `json:"result,omitempty"`; Error json.RawMessage `json:"error,omitempty"` }
var reads = map[string]bool{"eth_chainId":true,"net_version":true,"web3_clientVersion":true,"eth_blockNumber":true,"eth_getBalance":true,"eth_getBlockByNumber":true,"eth_getBlockByHash":true}
var origins = map[string]bool{"https://swarm-space.lovable.app":true,"https://id-preview--60db83b9-24c7-4fa3-823d-71fa3a29a5bc.lovable.app":true,"http://localhost:8080":true}
type Bridge struct { mu sync.Mutex; token string; last time.Time; origin string; queue []Job; pending map[string]chan Reply; window time.Time; count int }
func random() string { b:=make([]byte,32); if _,err:=rand.Read(b);err!=nil { log.Fatal(err) }; return hex.EncodeToString(b) }
func send(w http.ResponseWriter, v any) { w.Header().Set("Content-Type","application/json"); w.Header().Set("Cache-Control","no-store"); json.NewEncoder(w).Encode(v) }
func rpcError(w http.ResponseWriter,id json.RawMessage,code int,msg string) { if len(id)==0 { id=json.RawMessage("null") }; send(w,map[string]any{"jsonrpc":"2.0","id":id,"error":map[string]any{"code":code,"message":msg}}) }
func (b *Bridge) ServeHTTP(w http.ResponseWriter,r *http.Request) {
 // Bind AND Host checks prevent LAN exposure and DNS rebinding.
 if r.Host!=host { http.Error(w,"Loopback host required",403);return }
 origin:=r.Header.Get("Origin")
 bridge:=strings.HasPrefix(r.URL.Path,"/bridge/")
 external:=strings.HasPrefix(origin,"chrome-extension://") || strings.HasPrefix(origin,"moz-extension://")
 if bridge && !origins[origin] { http.Error(w,"SWARM origin required",403);return }
 if origin!="" && !origins[origin] && !external { http.Error(w,"Origin denied",403);return }
 if origin!="" { w.Header().Set("Access-Control-Allow-Origin",origin);w.Header().Set("Vary","Origin") }
 w.Header().Set("Access-Control-Allow-Methods","GET, POST, OPTIONS")
 w.Header().Set("Access-Control-Allow-Headers","Authorization, Content-Type")
 w.Header().Set("Access-Control-Allow-Private-Network","true")
 if r.Method=="OPTIONS" {w.WriteHeader(204);return}
 r.Body=http.MaxBytesReader(w,r.Body,64*1024)
 if bridge {
  // The printed one-time code never appears in health or RPC responses.
  if r.Header.Get("Authorization")!="Bearer "+b.token {http.Error(w,"Pairing denied",401);return}
  b.mu.Lock(); denied:=b.origin!="" && b.origin!=origin && time.Since(b.last)<5*time.Second; b.mu.Unlock()
  if denied {http.Error(w,"Already paired to another SWARM origin",409);return}
 }
 switch r.URL.Path {
 case "/health":
  if r.Method!="GET" {http.Error(w,"GET required",405);return}
  b.mu.Lock();ready:=time.Since(b.last)<5*time.Second;b.mu.Unlock()
  send(w,map[string]any{"protocol":protocol,"version":"1.0.0","bridgeReady":ready})
 case "/bridge/poll":
  if r.Method!="GET" {http.Error(w,"GET required",405);return}
  // Short long-poll keeps readiness fresh; a closed tab expires in five seconds.
  time.Sleep(500*time.Millisecond)
  b.mu.Lock();b.last=time.Now();b.origin=origin;jobs:=b.queue;b.queue=[]Job{};b.mu.Unlock()
  if jobs==nil {jobs=[]Job{}};send(w,jobs)
 case "/bridge/reply":
  if r.Method!="POST" {http.Error(w,"POST required",405);return}
  var reply Reply
  if json.NewDecoder(r.Body).Decode(&reply)!=nil {http.Error(w,"Invalid reply",400);return}
  b.mu.Lock();ch:=b.pending[reply.ID];b.mu.Unlock()
  if ch!=nil {select {case ch<-reply:default:}}
  send(w,map[string]bool{"ok":true})
 case "/rpc":
  if r.Method!="POST" {http.Error(w,"POST required",405);return}
  var req RPC;decoder:=json.NewDecoder(r.Body)
  if decoder.Decode(&req)!=nil {rpcError(w,nil,-32700,"Invalid JSON or batch not supported");return}
  var extra any
  if decoder.Decode(&extra)!=io.EOF || req.JSONRPC!="2.0" || len(req.ID)==0 || req.Method=="" {rpcError(w,req.ID,-32600,"Invalid JSON-RPC request");return}
  if !reads[req.Method] {rpcError(w,req.ID,-32601,"Read-only SWARM companion; transaction submission is not supported");return}
  b.mu.Lock()
  if time.Since(b.window)>time.Second {b.window=time.Now();b.count=0};b.count++
  if b.count>60 || len(b.pending)>=32 {b.mu.Unlock();rpcError(w,req.ID,-32005,"Too many requests");return}
  if time.Since(b.last)>=5*time.Second {b.mu.Unlock();rpcError(w,req.ID,-32000,"No paired online SWARM mesh");return}
  id:=random();ch:=make(chan Reply,1);b.pending[id]=ch;b.queue=append(b.queue,Job{id,req.Method,req.Params});b.mu.Unlock()
  defer func(){b.mu.Lock();delete(b.pending,id);for i,j:=range b.queue {if j.ID==id {b.queue=append(b.queue[:i],b.queue[i+1:]...);break}};b.mu.Unlock()}()
  select {
  case reply:=<-ch:
   if len(reply.Error)>0 && string(reply.Error)!="null" {send(w,map[string]any{"jsonrpc":"2.0","id":req.ID,"error":reply.Error})} else if len(reply.Result)>0 {send(w,map[string]any{"jsonrpc":"2.0","id":req.ID,"result":reply.Result})} else {rpcError(w,req.ID,-32603,"Missing mesh result")}
  case <-time.After(6*time.Second):rpcError(w,req.ID,-32000,"SWARM browser mesh did not respond")
  case <-r.Context().Done():
  }
 default:http.NotFound(w,r)
 }
}
func main(){
 b:=&Bridge{token:random(),pending:make(map[string]chan Reply)}
 fmt.Println("SWARM Local Companion 1.0.0 - read-only")
 fmt.Println("Leave this window open. No administrator privileges or wallet keys required.")
 fmt.Println("Open SWARM > Node > MetaMask Swarm Cell > Check companion, then pair.")
 fmt.Println("Pairing code (paste into SWARM only):",b.token)
 fmt.Println("RPC:","http://"+host+"/rpc")
 fmt.Println("Close this window or press Ctrl+C to stop. Nothing is installed at startup.")
 server:=&http.Server{Addr:host,Handler:b,ReadHeaderTimeout:3*time.Second,ReadTimeout:5*time.Second,WriteTimeout:10*time.Second,IdleTimeout:15*time.Second,MaxHeaderBytes:8192}
 if err:=server.ListenAndServe();err!=nil {fmt.Println("Could not start companion:",err);fmt.Println("Port 8545 may already be in use. Press Enter to close.");fmt.Scanln();os.Exit(1)}
}
