module swarm-local-companion

go 1.24
