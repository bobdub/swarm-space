SWARM Local Companion 1.0.0 (x64)

Windows: double-click swarm-companion-windows-x64.exe.
Linux: extract the archive, then open swarm-companion in a terminal.
If your desktop refuses to launch it, allow execution in Properties > Permissions.
Terminal alternative: ./swarm-companion
Unsigned downloads may trigger operating-system warnings. No admin rights needed.

Keep the companion window and SWARM open. In SWARM, sign in, connect MetaMask,
and join an online mesh peer. Open Node > MetaMask Swarm Cell > Check companion.
Paste the pairing code from this window; never share that code elsewhere.
Click Pair companion, then Add local SWARM network to MetaMask.
Chain ID: 74747 (0x123fb). RPC URL: http://127.0.0.1:8545/rpc

This release is read-only. It relays reads from the actual online browser mesh.
It does NOT execute EVM transactions or support sending from MetaMask.
The native ledger adapter is not a complete EVM chain.
Balances and blocks depend on your browser's local synchronized view.
No private keys or backup credentials are collected.
No public server, cloud relay, auto-start, or permanent installation is used.
Close the companion or press Ctrl+C to stop. Re-pair after restarting it.
If port 8545 is occupied, close the other program or companion instance.
Mobile MetaMask cannot reach your desktop's localhost.

Source and tests: swarm-companion-source.zip beside this download.
Build with Go 1.24+ using: go build -trimpath -o swarm-companion .
Test with: go test .
Cross-compile Windows: GOOS=windows GOARCH=amd64 go build -o swarm-companion.exe .
